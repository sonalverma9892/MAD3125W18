package com.example.admin.practice;

import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

/**
 * Created by ADMIN on 22-04-2018.
 */



public class MyAdapter extends BaseAdapter {

    private final Context mContext;
    public int[]  images = {R.drawable.img1, R.drawable.img2, R.drawable.img3, R.drawable.img4, R.drawable.img5};
    LayoutInflater inflater;

    public MyAdapter(Context mContext) {
        this.mContext = mContext;
        inflater = ( LayoutInflater )mContext.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public int getCount() {
        return images.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ImageView img;
        if (view == null) {
            img = new ImageView(mContext);
            // Center crop image
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } else {
            img = (ImageView) view;
        }
        view = inflater.inflate(R.layout.custom_grid, null);
        img = (ImageView) view.findViewById(R.id.imgRand);
        img.setImageResource(images[i]);

        return img;
    }
}
