package com.example.macstudent.midtermrecommended;

/**
 * Activity Selected
 * 0 = first nav
 * 1 = second nav
 * 2 = third nav
 */
public class GlobalClass {
    public static int ActivitySelected = 0;

    //Google queryString
    public static String queryString = "";

    // 0 = not, 1 = yes
    public static int QuestionAnswered = 0;
}
