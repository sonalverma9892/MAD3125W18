package com.example.macstudent.midtermrecommended;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{


    TextView typeQuestion;
    DBHelper dbHelper;
    SQLiteDatabase pollDB;
    TextView questionDescription;
    RadioButton radioButtonOne;
    RadioButton radioButtonTwo;
    RadioButton radioButtonThree;
    RadioButton radioButtonFour;
    Button buttonOne;
    Button buttonTwo;
    Button buttonThree;
    Button buttonFour;
    Button buttonSubmit;
    String countOption1 = "0";
    String countOption2 = "0";
    String countOption3 = "0";
    String countOption4 = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //region CONTROLS
        typeQuestion = (TextView) findViewById(R.id.txtTypeQuestionMain);
        questionDescription = (TextView) findViewById(R.id.txtQuestionMain);
        radioButtonOne = (RadioButton) findViewById(R.id.radioButtonOne);
        radioButtonTwo = (RadioButton) findViewById(R.id.radioButtonTwo);
        radioButtonThree = (RadioButton) findViewById(R.id.radioButtonThree);
        radioButtonFour = (RadioButton) findViewById(R.id.radioButtonFour);
        buttonOne = (Button) findViewById(R.id.btnQuestionOne);
        buttonOne.setOnClickListener(this);
        buttonTwo = (Button) findViewById(R.id.btnQuestionTwo);
        buttonTwo.setOnClickListener(this);
        buttonThree = (Button) findViewById(R.id.btnQuestionThree);
        buttonThree.setOnClickListener(this);
        buttonFour = (Button) findViewById(R.id.btnQuestionFour);
        buttonFour.setOnClickListener(this);
        buttonSubmit = (Button) findViewById(R.id.btnSubmitMain);
        buttonSubmit.setOnClickListener(this);
        //endregion


        dbHelper = new DBHelper(this);

        //There is a primary key, so it does not need to do the treatment to check if the data is already there
        dbHelper.insertData(getApplicationContext());


        switch (GlobalClass.ActivitySelected){
            case 0:
                typeQuestion.setText("Tim");
                displayData(0);
                break;
            case 1:
                typeQuestion.setText("Technology");
                displayData(1);
                break;
            case 2:
                typeQuestion.setText("Politics");
                displayData(2);
                break;
        }




    }

    private void setControlsValues(String questionDescription,String radioButtonOneDesc, String radioButtonTwoDesc, String radioButtonThreeDesc, String radioButtonFourDesc){
        this.questionDescription.setText(questionDescription);
        this.radioButtonOne.setText(radioButtonOneDesc);
        this.radioButtonTwo.setText(radioButtonTwoDesc);
        this.radioButtonThree.setText(radioButtonThreeDesc);
        this.radioButtonFour.setText(radioButtonFourDesc);
    }

    private void displayData(int typeDisplay){

        try{
            pollDB = dbHelper.getReadableDatabase();

            String columns[] = {"Question", "Option1", "Option2", "Option3", "Option4", "CountOption1", "CountOption2", "CountOption3", "CountOption4"};

            Cursor cursor = pollDB.query("Poll"
                    ,columns,null,null,
                    null,null,null);

            int type = 0;
            while (cursor.moveToNext()){
                if(type == typeDisplay){
                String question = cursor.getString
                        (cursor.getColumnIndex("Question"));
                String option1 = cursor.getString(
                        cursor.getColumnIndex("Option1")
                );

                String option2 = cursor.getString(
                        cursor.getColumnIndex("Option2")
                );

                String option3 = cursor.getString(
                        cursor.getColumnIndex("Option3")
                );

                String option4 = cursor.getString(
                        cursor.getColumnIndex("Option4")
                );

                this.countOption1 = cursor.getString(
                        cursor.getColumnIndex("CountOption1")
                );
                if(countOption1 == ""){
                    this.countOption1 = "0";
                }

                    this.countOption2 = cursor.getString(
                        cursor.getColumnIndex("CountOption2")
                );
                    if(countOption2 == ""){
                        this.countOption2 = "0";
                    }

                    this.countOption3 = cursor.getString(
                        cursor.getColumnIndex("CountOption3")
                );
                    if(countOption3 == ""){
                        this.countOption3 = "0";
                    }

                    this.countOption4 = cursor.getString(
                        cursor.getColumnIndex("CountOption4")
                );
                    if(countOption4 == ""){
                        this.countOption4 = "0";
                    }




                String pollInfo = question + "\n" + option1 + "\n"+
                        option2 + "\n" + option3 + "\n" +
                        option4;

                //Toast.makeText(this,pollInfo, Toast.LENGTH_LONG).show();
                    setControlsValues(question, option1, option2, option3, option4);
                }
                type++;
            }


        }catch (Exception e){
            Log.e("RegisterActivity : ",
                    "Unable to fetch the records");
        }

        pollDB.close();

    }

    @Override
    public void onClick(View view) {

        Intent GoogleRedirect = new Intent(getApplicationContext(), GoogleActivity.class);

        switch (view.getId()){
            case R.id.btnQuestionOne:
                GlobalClass.queryString = radioButtonOne.getText().toString();
                startActivity(GoogleRedirect);
                break;
            case R.id.btnQuestionTwo:
                GlobalClass.queryString = radioButtonTwo.getText().toString();
                startActivity(GoogleRedirect);
                break;
            case R.id.btnQuestionThree:
                GlobalClass.queryString = radioButtonThree.getText().toString();
                startActivity(GoogleRedirect);
                break;
            case R.id.btnQuestionFour:
                GlobalClass.queryString = radioButtonFour.getText().toString();
                startActivity(GoogleRedirect);
                break;
            case R.id.btnSubmitMain:
                if(checkVoteSelected()){
                    voteCounted();
                    GlobalClass.QuestionAnswered = 1;
                    Intent HomeRedirect = new Intent(getApplicationContext(), HomeActivity.class);
                    startActivity(HomeRedirect);
                }else{
                    Toast.makeText(this, "Select one vote", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    public void voteCounted(){

        try{
            //get the number of votes
            Integer countOpt1Int = Integer.parseInt(countOption1);
            Integer countOpt2Int = Integer.parseInt(countOption2);
            Integer countOpt3Int = Integer.parseInt(countOption3);
            Integer countOpt4Int = Integer.parseInt(countOption4);

            String questionType = typeQuestion.getText().toString();
            //update te number of votes
            if (radioButtonOne.isChecked()){
                countOpt1Int++;
                dbHelper.updateData(getApplicationContext(), questionType, "CountOption1", countOpt1Int.toString());
            }
            else if (radioButtonTwo.isChecked()){
                countOpt2Int++;
                dbHelper.updateData(getApplicationContext(), questionType, "CountOption2", countOpt2Int.toString());
            }
            else if (radioButtonThree.isChecked()){
                countOpt3Int++;
                dbHelper.updateData(getApplicationContext(), questionType,"CountOption3",  countOpt3Int.toString());
            }
            else if (radioButtonFour.isChecked()){
                countOpt4Int++;
                dbHelper.updateData(getApplicationContext(), questionType, "CountOption4", countOpt4Int.toString());
            }
        }catch (Exception e){
            Toast.makeText(this, "Ocurred a problem in the updating countoptions", Toast.LENGTH_SHORT).show();
        }




    }

    boolean checkVoteSelected(){
        boolean someRadioButtonsSelected = false;

        if (radioButtonOne.isChecked()){
            someRadioButtonsSelected = true;
        }
        else if (radioButtonTwo.isChecked()){
            someRadioButtonsSelected = true;
        }
        else if (radioButtonThree.isChecked()){
            someRadioButtonsSelected = true;
        }
        else if (radioButtonFour.isChecked()){
            someRadioButtonsSelected = true;
        }

        return someRadioButtonsSelected;
    }
}
