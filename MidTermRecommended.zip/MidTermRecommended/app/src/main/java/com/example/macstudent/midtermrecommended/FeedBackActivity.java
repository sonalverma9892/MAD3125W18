package com.example.macstudent.midtermrecommended;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class FeedBackActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnSend;
    TextView subject;
    TextView bodyMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed_back);

        btnSend = (Button) findViewById(R.id.btnSendFeedback);
        btnSend.setOnClickListener(this);

       subject = (TextView) findViewById(R.id.txtSubjectFeedback);
        bodyMessage = (TextView) findViewById(R.id.txtBodyMessage);
    }

    private void sendEmail(String subject, String emailBody){
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("text/plain");

        emailIntent.putExtra(Intent.EXTRA_EMAIL,
                new String[]{"jigisha.patel@cestarcollege.com"});

        emailIntent.putExtra(Intent.EXTRA_SUBJECT,
                subject);
        emailIntent.putExtra(Intent.EXTRA_TEXT,
                emailBody);

        emailIntent.setType("message/rfc822");

        startActivity(Intent.createChooser(emailIntent,
                "Select Email Client"));
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnSendFeedback){
            sendEmail(this.subject.getText().toString(), this.bodyMessage.getText().toString());
            Toast.makeText(this, "Sending message", Toast.LENGTH_SHORT).show();
        }
    }
}
