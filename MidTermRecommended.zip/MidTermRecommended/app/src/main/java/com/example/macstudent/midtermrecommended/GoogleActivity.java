package com.example.macstudent.midtermrecommended;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class GoogleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google);

        WebView webManual = (WebView) findViewById(R.id.webView);

        String queryString = "http://www.google.com/search?q=" + GlobalClass.queryString.toString();
        webManual.loadUrl(queryString);
    }
}
