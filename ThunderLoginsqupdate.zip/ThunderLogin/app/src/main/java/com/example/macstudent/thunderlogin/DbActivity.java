package com.example.macstudent.thunderlogin;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class DbActivity extends AppCompatActivity {
    SQLiteDatabase thunderDB;
    DBHelper dbHelper;
    TextView txtdb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_db);

        TextView txtdb = (TextView) findViewById(R.id.txtDb);

        try{
            thunderDB = dbHelper.getReadableDatabase();
            String columns[] = {"Name", "Phone", "Email", "Password", "DOB"};
            Cursor cursor = thunderDB.query("UserInfo",columns,null,null,null,null,null);

            while(cursor.moveToNext()){
                String name = cursor.getString(cursor.getColumnIndex("Name"));
                String email = cursor.getString(cursor.getColumnIndex("Email"));
                String phone = cursor.getString(cursor.getColumnIndex("Phone"));
                String password = cursor.getString(cursor.getColumnIndex("Password"));
                String birthDate = cursor.getString(cursor.getColumnIndex("DOB"));

                String userInfo = name + "\n" + phone + "\n" + email + "\n" + password + "\n" +birthDate;
                txtdb.setText(userInfo);

//                Toast.makeText(this, userInfo, Toast.LENGTH_SHORT).show();

            }


        }catch(Exception e){
            Log.e("RegisterActivity : ", "Unable to fetch the records");
        }
        thunderDB.close();
    }
}
