package com.example.macstudent.melody;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by macstudent on 2018-04-23.
 */

public class MelodyAdapter extends BaseAdapter {

    public int[] albumLogo = {R.drawable.img21, R.drawable.img22, R.drawable.img23, R.drawable.img24, R.drawable.img25, R.drawable.img26};
    public String albumName[] = {"Dicotomy", "Thunder", "LaLaLand", "Despacito", "Rock", "Spring"};

    LayoutInflater layoutInflater;
    Context context;

    MelodyAdapter(Context context){
        this.context = context;
    layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return albumName.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        view = layoutInflater.inflate(R.layout.customgrid, null);

        ImageView imgAlbum = (ImageView) view.findViewById(R.id.imgAlbum);
        imgAlbum.setImageResource(albumLogo[position]);

        TextView txtAlbum = (TextView) view.findViewById(R.id.txtAlbum);
        txtAlbum.setText(albumName[position]);


        return view;
    }
}
