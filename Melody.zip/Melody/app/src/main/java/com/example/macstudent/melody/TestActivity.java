package com.example.macstudent.melody;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class TestActivity extends AppCompatActivity {
    MediaPlayer mediaPlayer;
    private int startTime = 0;
    private int finalTime = 0;
    private Handler myHandler = new Handler();
    private int seekTime = 5000;
    SeekBar seekBarProgress;
    TextView txtDuration;
    ImageButton imgPlay, imgPause, imgForward, imgRewind, imgStop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        ImageView imageView = (ImageView) findViewById(R.id.imgMyAlbum);

        Intent single = getIntent();

        int i = single.getIntExtra("album", R.drawable.img21);

        // Open the Image adapter
        MelodyAdapter melodyAdapter = new MelodyAdapter(this);

        // Get image and position from ImageAdapter.java and set into ImageView
        imageView.setImageResource(melodyAdapter.albumLogo[i]);



        seekBarProgress = (SeekBar) findViewById(R.id.seekBarProgress);
        imgPause = (ImageButton)findViewById(R.id.imgPause);
        imgPlay = (ImageButton)findViewById(R.id.imgPlay);
        imgForward = (ImageButton)findViewById(R.id.imgForward);
        imgRewind = (ImageButton)findViewById(R.id.imgRewind);
        imgStop = (ImageButton)findViewById(R.id.imgStop);

        //Create MediaPlayer
        mediaPlayer = MediaPlayer.create(getApplicationContext(),
                R.raw.dichotomy);
        finalTime = mediaPlayer.getDuration();
        startTime = mediaPlayer.getCurrentPosition();
        seekBarProgress.setMax((int) finalTime);


        txtDuration = (TextView) findViewById(R.id.txtDuration);

        imgPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.start();
                seekBarProgress.setProgress((int) startTime);
                myHandler.postDelayed(UpdateSongTime, 100);
            }
        });

        imgPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.pause();
            }
        });

        imgStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.stop();
            }
        });

        imgForward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentPosition = mediaPlayer.getCurrentPosition();
                if (currentPosition + seekTime <= mediaPlayer.getDuration()) {
                    mediaPlayer.seekTo(currentPosition + seekTime);
                } else {
                    mediaPlayer.seekTo(mediaPlayer.getDuration());
                }
            }
        });

        imgRewind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentPosition = mediaPlayer.getCurrentPosition();
                if (currentPosition - seekTime >= 0) {
                    mediaPlayer.seekTo(currentPosition - seekTime);
                } else {
                    mediaPlayer.seekTo(0);
                }
            }
        });
    }

    private Runnable UpdateSongTime = new Runnable() {
        public void run() {
            startTime = mediaPlayer.getCurrentPosition();
            txtDuration.setText(String.format("%d min, %d sec",
                    TimeUnit.MILLISECONDS.toMinutes((long) startTime),
                    TimeUnit.MILLISECONDS.toSeconds((long) startTime) -
                            TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.
                                    toMinutes((long) startTime)))
            );
            seekBarProgress.setProgress((int) startTime);
            myHandler.postDelayed(this, 100);
        }
    };
}
