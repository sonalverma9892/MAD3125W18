package com.example.macstudent.contacts;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by macstudent on 2018-04-20.
 */

public class ContactsAdapter extends BaseAdapter {
    String names[] = {"JK", "KK", "SV", "PK", "CK", "AK", "KK"};
    String phones[] = {"123", "235", "567", "890", "987", "567", "485"};
    LayoutInflater layoutInflater;
    Context context;
    TextView txtPhone, txtInitials;
    int totalContacts = 0;
    ArrayList<String> arName;
    ArrayList<String> arPhone;


    ContactsAdapter(Context context){
        this.context = context;
        arName = new ArrayList<String>();
        arPhone = new ArrayList<String>();
        getContactList();
        layoutInflater = (LayoutInflater.from(context));
    }

    @Override
    public int getCount() {
        return totalContacts;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {

        convertView = layoutInflater.inflate(R.layout.contacts_grid_item,null);

        txtInitials = convertView.findViewById(R.id.txtInitial);
        txtInitials.setText(String.valueOf(arName.get(i).charAt(0)));

        txtPhone = convertView.findViewById(R.id.txtPhone);
        txtPhone.setText(arPhone.get(i));

        return convertView;
    }

    private void getContactList() {
        ContentResolver cr = context.getContentResolver();
        Cursor cursor = cr.query(ContactsContract.Contacts.CONTENT_URI,
                null, null, null, null);

        if ((cursor != null ? cursor.getCount() : 0) > 0) {
            totalContacts = cursor.getCount();

            while (cursor != null && cursor.moveToNext()) {
                String id = cursor.getString(
                        cursor.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cursor.getString(cursor.getColumnIndex(
                        ContactsContract.Contacts.DISPLAY_NAME));

                if (cursor.getInt(cursor.getColumnIndex(
                        ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                    Cursor pCur = cr.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id}, null);

                    while (pCur.moveToNext()) {
                        String phoneNo = pCur.getString(pCur.getColumnIndex(
                                ContactsContract.CommonDataKinds.Phone.NUMBER));

                        arName.add(name);
                        arPhone.add(phoneNo);
                        Log.i("contactList", "Name: " + name);
                        Log.i("contactList", "Phone Number: " + phoneNo);
                    }
                    pCur.close();
                }
            }
        }
        if(cursor!=null){
            cursor.close();
        }

    }
}
