package com.example.macstudent.practice;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnLogin;
    EditText username;
    EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = (EditText) findViewById(R.id.edtUsername);
        password = (EditText) findViewById(R.id.edtPassword);

        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnLogin.getId()){
            String uname = username.getText().toString();
            String pass = password.getText().toString();

            if(uname.equals("test") && pass.equals("test")){
                Toast.makeText(this,"Login Successfull", Toast.LENGTH_LONG).show();

                Intent homeInetent = new Intent(this,HomeActivity.class);
                startActivity(homeInetent);

            }
        }

    }
}
