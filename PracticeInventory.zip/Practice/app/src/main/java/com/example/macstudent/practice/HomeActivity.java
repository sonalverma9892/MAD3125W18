package com.example.macstudent.practice;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener{
    Spinner productNo, productName;
    String no, name;
    ImageView imglogo;
    String productno[]= {"1", "2", "3", "4", "5"};
    String productname[]={"BMW", "Audi", "Marcedes", "Jaguar", "Lexus"};
    int logos[]={R.drawable.img_bmw, R.drawable.img_audi, R.drawable.img_mercedes, R.drawable.img_jaguar, R.drawable.img_lexus};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        productNo = (Spinner) findViewById(R.id.spinProductNo);
        ArrayAdapter adaptNo = new ArrayAdapter(this, android.R.layout.simple_spinner_item, productno);
        adaptNo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        productNo.setAdapter(adaptNo);
        productNo.setOnItemSelectedListener(this);

        productName = (Spinner) findViewById(R.id.spinProductName);
        ArrayAdapter adaptName = new ArrayAdapter(this,android.R.layout.simple_spinner_item,productname);
        adaptName.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        productName.setAdapter(adaptName);
        productName.setOnItemSelectedListener(this);

        imglogo = (ImageView) findViewById(R.id.imgLogo);



    }

    @Override
    public void onClick(View view) {

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
        if(adapterView.getId() == productNo.getId()){
            Toast.makeText(this,productno[position], Toast.LENGTH_LONG).show();
            no = productno[position];
        }else if(adapterView.getId() == productName.getId()){
            Toast.makeText(this,productname[position], Toast.LENGTH_LONG).show();
            name = productname[position];
            if(position==0)
            {

                imglogo.setImageResource(R.drawable.img_bmw);
            }
            else if(position==1)
            {
                imglogo.setImageResource(R.drawable.img_audi);
            }
            else if(position==2)
            {
                imglogo.setImageResource(R.drawable.img_mercedes);
            }else if(position==3)
            {
                imglogo.setImageResource(R.drawable.img_jaguar);
            }
            else if(position==4)
            {
                imglogo.setImageResource(R.drawable.img_lexus);
            }
        }



    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
