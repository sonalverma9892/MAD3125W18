package com.example.macstudent.listview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MyActivity extends AppCompatActivity {
    ImageView myImageView;
    TextView myTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        myImageView = (ImageView) findViewById(R.id.showImage);
        myTextView = (TextView) findViewById(R.id.showText);

        Intent single = getIntent();

        int position = single.getExtras().getInt("ID");
        CustomAdapter adapter = new CustomAdapter(this);

        myImageView.setImageResource(adapter.imgLogo[position]);
        myTextView.setText(adapter.cars[position]);


    }
}
