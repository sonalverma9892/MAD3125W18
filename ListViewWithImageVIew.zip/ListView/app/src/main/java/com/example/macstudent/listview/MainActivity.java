package com.example.macstudent.listview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    ListView myListView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myListView = (ListView) findViewById(R.id.myListView);

        CustomAdapter customAdapter = new CustomAdapter(this);
        myListView.setAdapter(customAdapter);

        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent myIntent = new Intent(getApplicationContext(), MyActivity.class);
                myIntent.putExtra("ID", i);
                startActivity(myIntent);
            }
        });


    }

//    class CustomAdapter extends BaseAdapter{
//
//        @Override
//        public int getCount(){
//            return imgLogo.length;
//
//        }
//
//        @Override
//        public Object getItem(int i){
//            return null;
//        }
//        @Override
//        public long getItemId(int i){
//            return 0;
//        }
//        @Override
//        public View getView(int i, View view, ViewGroup viewGroup){
//            view = getLayoutInflater().inflate(R.layout.listview, null);
//
//            ImageView imageView = (ImageView)view.findViewById(R.id.imgCar);
//            TextView txtCar = (TextView)view.findViewById(R.id.txtCar);
//
//            imageView.setImageResource(imgLogo[i]);
//            txtCar.setText(cars[i]);
//
//
//            return view;
//        }
//
//    }
}
