package com.example.macstudent.listview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    ListView myListView;
    String[] cars = {"BMW","Audi","Marcedes","Jaguar","Lexus"};
    int[] imgLogo = {R.drawable.img_bmw,R.drawable.img_audi,
            R.drawable.img_mercedes,R.drawable.img_jaguar,
            R.drawable.img_lexus};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myListView = (ListView) findViewById(R.id.myListView);

        CustomAdapter customAdapter = new CustomAdapter();
        myListView.setAdapter(customAdapter);


    }

    class CustomAdapter extends BaseAdapter{

        @Override
        public int getCount(){
            return imgLogo.length;

        }

        @Override
        public Object getItem(int i){
            return null;
        }
        @Override
        public long getItemId(int i){
            return 0;
        }
        @Override
        public View getView(int i, View view, ViewGroup viewGroup){
            view = getLayoutInflater().inflate(R.layout.listview, null);

            ImageView imageView = (ImageView)view.findViewById(R.id.imgCar);
            TextView txtCar = (TextView)view.findViewById(R.id.txtCar);

            imageView.setImageResource(imgLogo[i]);
            txtCar.setText(cars[i]);


            return view;
        }

    }
}
