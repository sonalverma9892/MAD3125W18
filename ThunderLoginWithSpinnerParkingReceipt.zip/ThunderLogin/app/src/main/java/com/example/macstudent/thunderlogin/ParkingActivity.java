package com.example.macstudent.thunderlogin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

public class ParkingActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener{
    RadioButton rdoHalf, rdoOne, rdoTwo, rdoThree;
    TextView txtAmount;
    TextView txtDateTime;

    int parkingRate[] = {5,10,20,35};
    String lots[] ={"A","B","C","D","E"};
    String spots[] = {"1","2","3","4","5"};
    String paymentMethods[] = {"Debit", "Visa", "MAster", "American Express"};
    Spinner spinLot, spinSpot, spinPayment, spinComapnay;
    String companyNames[]={"BMW", "Audi", "Marcedes", "Jaguar", "Lexus"};
    int logos[]={R.drawable.img_bmw, R.drawable.img_audi, R.drawable.img_mercedes, R.drawable.img_jaguar, R.drawable.img_lexus};

    String lot, spot, carPlate, payment, dateTime, company;
    int amount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking);

        rdoHalf = (RadioButton) findViewById(R.id.rdoHalfHour);
        rdoHalf.setOnClickListener(this);

        rdoOne = (RadioButton) findViewById(R.id.rdoOneHour);
        rdoOne.setOnClickListener(this);

        rdoTwo = (RadioButton) findViewById(R.id.rdoTwoHour);
        rdoTwo.setOnClickListener(this);

        rdoThree = (RadioButton) findViewById(R.id.rdoThreeHour);
        rdoThree.setOnClickListener(this);

        txtAmount = (TextView) findViewById(R.id.txtAmount);
        txtAmount.setText("$" + String.valueOf(parkingRate[0]));

        txtDateTime = (TextView) findViewById(R.id.txtDateTime);
        Date dt = Calendar.getInstance().getTime();
        txtDateTime.setText(dt.toString());

        spinLot = (Spinner) findViewById(R.id.spinLot);
        ArrayAdapter adaptLot = new ArrayAdapter(this, android.R.layout.simple_spinner_item, lots);
        adaptLot.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinLot.setAdapter(adaptLot);
        spinLot.setOnItemSelectedListener(this);

        spinSpot = (Spinner) findViewById(R.id.spinSpot);
        ArrayAdapter adaptSpot = new ArrayAdapter(this, android.R.layout.simple_spinner_item, spots);
        adaptLot.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinSpot.setAdapter(adaptSpot);
        spinSpot.setOnItemSelectedListener(this);

        spinPayment = (Spinner) findViewById(R.id.spinPayment);
        ArrayAdapter adaptPayment = new ArrayAdapter(this, android.R.layout.simple_spinner_item, paymentMethods);
        adaptLot.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinPayment.setAdapter(adaptPayment);
        spinPayment.setOnItemSelectedListener(this);

        spinComapnay = (Spinner) findViewById(R.id.spinCompany);
        CarAdapter carAdapter = new CarAdapter(getApplicationContext(), logos, companyNames);
        spinComapnay.setAdapter(carAdapter);
        spinComapnay.setOnItemSelectedListener(this);

    }

    @Override
    public void onClick(View view) {
        if (rdoHalf.isChecked()){
            txtAmount.setText("$" + String.valueOf(parkingRate[0]));
        }else if(rdoOne.isChecked()){
            txtAmount.setText("$" + String.valueOf(parkingRate[1]));

        }else if(rdoTwo.isChecked()){
            txtAmount.setText("$" + String.valueOf(parkingRate[2]));

        }else if(rdoThree.isChecked()){
            txtAmount.setText("$" + String.valueOf(parkingRate[3]));

        }

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
        if(adapterView.getId() == spinLot.getId()){
            Toast.makeText(this,lots[position], Toast.LENGTH_LONG).show();
            lot = lots[position];
        }else if(adapterView.getId() == spinSpot.getId()){
            Toast.makeText(this,spots[position], Toast.LENGTH_LONG).show();
            spot = spots[position];
        }else if(adapterView.getId() == spinPayment.getId()){
            Toast.makeText(this,paymentMethods[position], Toast.LENGTH_LONG).show();
            payment = paymentMethods[position];
        }else if(adapterView.getId() == spinComapnay.getId()){
            company = companyNames[position];
            Toast.makeText(this,companyNames[position], Toast.LENGTH_LONG).show();

        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
